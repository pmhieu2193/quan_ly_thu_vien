<?php
if(!isset($_POST["delete"])){
    echo 'delete';

}

?>